package com.sofia.onestatetools;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.widget.*;
import android.graphics.Typeface;
import android.view.View;
import android.view.Gravity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;

public class MainActivity extends Activity {
    private final String gamePackage = "com.Chillgaming.oneState";
    private LinearLayout root;
    private TextView networkStatus, deviceStatus;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void addCard(String title, String body) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(bg(Color.rgb(35, 40, 52), 16));
        TextView h = text(title, 17, Color.WHITE, true);
        TextView b = text(body, 14, Color.rgb(205, 211, 222), false);
        b.setPadding(0, dp(7), 0, 0);
        card.addView(h); card.addView(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12)); root.addView(card, lp);
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(bg(Color.rgb(62, 112, 220), 14));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(18, 22, 31));
        getWindow().setNavigationBarColor(Color.rgb(18, 22, 31));
        getWindow().getDecorView().setSystemUiVisibility(0);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(18, 22, 31));
        scroll.addView(root);
        setContentView(scroll);

        TextView eyebrow = text("SAMSUNG GALAXY A52s • ANDROID", 11, Color.rgb(145, 165, 205), true);
        root.addView(eyebrow);
        TextView title = text("OneState Tools", 29, Color.WHITE, true);
        title.setPadding(0, dp(5), 0, dp(4)); root.addView(title);
        root.addView(text("Pendamping ringan untuk membantu memeriksa koneksi dan menyiapkan perangkat sebelum bermain.", 14, Color.rgb(195, 202, 216), false));

        networkStatus = text("", 14, Color.WHITE, true);
        networkStatus.setPadding(dp(14), dp(12), dp(14), dp(12));
        networkStatus.setBackground(bg(Color.rgb(35, 40, 52), 14));
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2);
        nlp.setMargins(0, dp(18), 0, dp(12)); root.addView(networkStatus, nlp);
        deviceStatus = text("", 14, Color.rgb(205, 211, 222), false);
        deviceStatus.setPadding(0, 0, 0, dp(12)); root.addView(deviceStatus);

        root.addView(button("Periksa koneksi internet", this::checkNetwork), params());
        root.addView(button("Buka OneState RP", this::openGame), params());
        root.addView(button("Tips optimasi performa", this::showTips), params());

        addCard("Yang dapat dilakukan",
            "• Memeriksa apakah perangkat memiliki koneksi internet aktif.\n" +
            "• Membuka aplikasi OneState yang sudah terpasang.\n" +
            "• Menampilkan panduan pengaturan performa Android.");
        addCard("Batasan keamanan",
            "Aplikasi ini tidak mengubah APK/game, saldo, stamina, oksigen, atau data server. " +
            "Tidak ada izin Accessibility, overlay, SMS, kontak, atau akses file yang diminta.");
        addCard("Jika muncul UNKNOWN",
            "Coba jaringan lain, matikan VPN/DNS pribadi sementara, pastikan tanggal dan waktu otomatis, " +
            "lalu uji aplikasi OneState resmi. Jika hanya MOD yang gagal, kemungkinan masalah ada pada MOD/server.");

        deviceStatus.setText("Perangkat: " + Build.MANUFACTURER + " " + Build.MODEL +
            "\nAndroid: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")" +
            "\nArsitektur: " + (Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "Tidak diketahui"));
        checkNetwork();
    }

    private LinearLayout.LayoutParams params() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.setMargins(0, 0, 0, dp(10)); return p;
    }

    private void checkNetwork() {
        boolean connected = false;
        String kind = "Tidak ada koneksi terdeteksi";
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
            if (c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                connected = true;
                kind = c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi terhubung" :
                    c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Data seluler terhubung" : "Jaringan terhubung";
            }
        } catch (Exception ignored) {}
        networkStatus.setText((connected ? "● " : "● ") + kind +
            "\nPemeriksaan ini melihat koneksi perangkat, bukan status server OneState.");
        networkStatus.setTextColor(connected ? Color.rgb(135, 230, 170) : Color.rgb(255, 180, 120));
    }

    private void openGame() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(gamePackage);
        if (launch == null) {
            new AlertDialogBuilder(this).showMessage("OneState belum ditemukan. Instal aplikasi resmi OneState terlebih dahulu.");
        } else {
            try { startActivity(launch); }
            catch (Exception e) { new AlertDialogBuilder(this).showMessage("Tidak dapat membuka OneState: " + e.getMessage()); }
        }
    }

    private void showTips() {
        new AlertDialogBuilder(this).showMessage(
            "Sebelum bermain:\n\n" +
            "1. Tutup aplikasi berat yang tidak dipakai.\n" +
            "2. Sisakan ruang penyimpanan yang cukup.\n" +
            "3. Atur grafis di dalam game sesuai suhu dan kestabilan FPS.\n" +
            "4. Hindari bermain sambil mengisi daya jika perangkat panas.\n" +
            "5. Gunakan koneksi stabil dan nonaktifkan VPN jika mengganggu.\n\n" +
            "Aplikasi ini tidak dapat menaikkan FPS secara ajaib atau mengubah performa server."
        );
    }

    static class AlertDialogBuilder {
        private final Activity a;
        AlertDialogBuilder(Activity a) { this.a = a; }
        void showMessage(String s) {
            new android.app.AlertDialog.Builder(a).setTitle("OneState Tools")
                .setMessage(s).setPositiveButton("Tutup", null).show();
        }
    }
}
